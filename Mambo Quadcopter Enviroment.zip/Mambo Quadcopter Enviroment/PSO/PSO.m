%%%Main%%%
save_time= 5;
verbose = 1;
D=NaN;
P=NaN;
I=NaN;

%% Problem Defifnition
CostFunction=@(x) cost_function(x); % Cost Function
params=3;
dt = 0.25;                           % Delta Time

% Variable Limits
x_max = [ 0.1 0.1 0.028];                    % Upper Bound of Variables
x_min = [ 0 0 0];                    % Lower Bound of Variables
v_max = dt*(x_max-x_min);           % Upper Bound of Velocity
v_min = -v_max;                     % Lower Bound of Velocity

nVar = length(x_max);               % Number of Decision Variables
problem = 'min';
%% PSO Parameters
epochs = 55;                       % Maximum Number of Iterations
N = 20;                             % Number of Particles
delta = 1e-9;                       % Cost variance to stop the algorithm
patience = 10;                       % Number of epochs under delta cost variation
damp = [1 0.4 0.5];                 % W damping parameters initial, final, ratio
C = [1 0.4 0.6];                    % Inertia, Personal Learning, Global Learning
%% Initialization
particles = Particle.empty(N, 0);

HistVal = double.empty(length(epochs), 0);
HistPosPar = double.empty(length(epochs), N, 0);
HistW = double.empty(length(epochs), 0);
dcost = Inf;

for i =     1:N
    particles(i) = Particle(rand(1,params).*(x_max-x_min)+x_min,... %x
                            rand(1,params).*(v_max-v_min)+v_min,... %v 
                            problem);
end

%% PSO Main Loop
for i = 1:epochs
    
    values = double.empty(N, 0);
    for p = 1:length(particles)
        % Evaluate
        position_p=particles(p).get_position();
        P=position_p(1);
        I=position_p(2);
        D=position_p(3);
        particles(p).evaluate(CostFunction);
        values(p) = particles(p).get_value();
    end
    % Find Best Position
    bestValEnj = min(values);
    bestPosEnj = particles(find(values==bestValEnj, 1, 'first')).get_position();
        
    for p = particles    
        p.update_speed(bestPosEnj, C);         % Update Velocity
        p.trim_speed_limits(v_min, v_max);     % Apply Velocity Limits
        p.update_pos(dt);                      % Update Position
        p.mirror_speed(x_min, x_max);          % Velocity Mirror Effect
        p.trim_position_limits(x_min, x_max);  % Apply Position Limits
    end
    
    if verbose==1
        disp(['Epochs=' string(i) 'Best Position=' num2str(bestPosEnj(:).') 'Best Value=' string(bestValEnj)])
    end
    HistVal(i) = bestValEnj;
    
    for n = 1:N
        hpp = particles(n).get_position();
        for m = 1:nVar
            HistPosPar(i, n, m) = hpp(m);
        end
    end
    HistW(i) = C(1);
    C(1) = (damp(1)-damp(2))*(1-(i/epochs)^damp(3))+damp(2);  % Slow Down the Particles
    
    if i>1    
        dcost = abs(HistVal(i)-HistVal(i-1));
    end
    
    if dcost< delta
        d=d+1;
    else
        d=0;
    end
    
    if d>patience
        n = i;
        break
    end
end

figure
yyaxis right
plot(HistW, 'LineWidth',2)
ylabel('Inertia Value');
yyaxis left
semilogy(HistVal, 'LineWidth',2)
xlabel('Iteration');
ylabel('Best Cost');
grid on

figure(2)
for i = 1:n
    scatter(HistPosPar(i,:,1), HistPosPar(i,:,2), 20, 'r', 'o'), hold on
    if i==n
        scatter(HistPosPar(n,:,1), HistPosPar(n,:,2), 50, 'b', 'o'), grid on
    end
end

disp(['Solution=' string(bestPosEnj) 'Cost=' string(bestValEnj)]);


