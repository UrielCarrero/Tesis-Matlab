function val = cost_function(x)
    
    P = x(1);
    I = x(2);
    D = x(3);
    try
        simOut = sim('mainModels\test_asbQuadcopter', 'ReturnWorkspaceOutputs',95);
    
        Y=simOut.Roll_s.signals.values;
        Deseado=simOut.orient_r.signals.values(:,3);

        val = sum((Deseado-Y).^2)/(2*length(Y));
    catch
        val = Inf;
    end
    
end