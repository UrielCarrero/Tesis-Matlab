classdef Particle<handle
   properties (Access=private)
      position=0;
      speed=0;
      best_position=0;
      best_value=0;
      value=0;
      problem='min';
   end
   
   methods
      function obj = Particle(x, v, problem)
         if nargin<5
            obj.problem="min";
         else
            obj.problem=problem;
         end
         
         obj.position = x;
         obj.speed = v;
         obj.best_position = x;
         
         if obj.problem=="min"
            obj.best_value=Inf;
         else
            obj.best_value=-Inf;
         end  
         
         obj.value=0;
      end
      
      function value = evaluate(obj, cost_function)
         value = cost_function(obj.position);
         
         %Update Personal Best Value
         if obj.problem=="min"
             if value < obj.best_value
                 obj.best_value = value;
                 obj.best_position = obj.position;
             end
         else
             if value > obj.best_value
                 obj.best_value = value;
                 obj.best_position = obj.position;
             end
         end
         
         obj.value = value;
      end
      
      function update_speed(obj, best_enj_pos, C)
          rdn = rand(1, 2);

          %Update speed
          obj.speed = C(1).*obj.speed...
                    + C(2).*rdn(1).*(obj.best_position - obj.position)...
                    + C(3).*rdn(2).*(best_enj_pos      - obj.position);
      end
      
      function trim_speed_limits(obj, vel_min, vel_max)
          %Trim speed beetwen limits
          obj.speed = max(obj.speed, vel_min);
          obj.speed = min(obj.speed, vel_max);
      end
      
      function update_pos(obj, dt)
          %Update Position
          obj.position = obj.position+obj.speed*dt; 
      end
      
      function mirror_speed(obj, x_min, x_max)
          for i = 1:length(obj.position)
          %Velocity Mirror Effect when outside limits
              IsOutside = (obj.position(i)<x_min | obj.position(i)>x_max);
              if IsOutside
                  obj.speed(i)=-obj.speed(i);
              end
          end
      end
      
      function trim_position_limits(obj, x_min, x_max)
          %Trim position beetwen limits
          obj.position = max(obj.position, x_min);
          obj.position = min(obj.position, x_max);
      end
      
      function position = get_position(obj)
          position = obj.position;
      end
      
      function value = get_value(obj)
          value = obj.value;
      end
   end
end