function out = myprediction()

out=importKerasNetwork('Training\Models\LSTM XYZ_Yaw\DatasetXYZYaw_2022V2_0_32.h5')

end